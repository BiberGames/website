import pygame

pygame.init()

pygame.font.init()

win = pygame.display.set_mode((1200,600))
pygame.display.set_caption("BOMBS")
programIcon = pygame.image.load('sprites/ICON.png')

bg = pygame.image.load('sprites/BACKGROUND_MASK.png')

bomb_sprite = pygame.image.load('sprites/BOMB.png')
bomb2_sprite = pygame.image.load('sprites/BOMB.png')

walkRight_red = [pygame.image.load('sprites/player/RED/RED_R_1.png'), pygame.image.load('sprites/player/RED/RED_R_2.png')]
walkLeft_red = [pygame.image.load('sprites/player/RED/RED_L_1.png'), pygame.image.load('sprites/player/RED/RED_L_2.png')]
char_red = pygame.image.load('sprites/player/RED/RED.png')

walkRight_green = [pygame.image.load('sprites/player/GREEN/GREEN_R_1.png'), pygame.image.load('sprites/player/GREEN/GREEN_R_2.png')]
walkLeft_green = [pygame.image.load('sprites/player/GREEN/GREEN_L_1.png'), pygame.image.load('sprites/player/GREEN/GREEN_L_2.png')]
char_green = pygame.image.load('sprites/player/GREEN/GREEN.png')

explosion1_sprite = pygame.image.load('sprites/EXPLOSION.png')
explosion2_sprite = pygame.image.load('sprites/EXPLOSION.png')

BOOM = pygame.mixer.Sound('sounds/EXPLOSION.wav')

clock = pygame.time.Clock()

pygame.display.set_icon(programIcon)

x = 30
y = 300

x2 = 1140
y2 = 300

width = 30
height = 30
vel = 15

vel2 = 15

border = 30

run = True

left = False
right = False
walkCount = 0

left2 = False
right2 = False
walkCount2 = 0

#print("Name for Player Green; ")
#NAME1 = input() 

#print("Name for Player Red; ")
#NAME2 = input()

NAME1 = "Green"
NAME2 = "Red"

bomb1_timer = 5000
bomb2_timer = 5000

print("Start!!!")

myfont = pygame.font.SysFont('airal', 26)
myfont2 = pygame.font.SysFont('airal', 26)

P1_NAME = myfont.render(NAME1, False, (0, 0, 0))
P2_NAME = myfont2.render(NAME2, False, (0, 0, 0))

bomb1 = False
bomb2 = False

bomb1x = 0
bomb1y = 0

bomb2x = 0
bomb2y = 0

bomb1_placed = False
bomb2_placed = False

explosion1 = False
explosion2 = False

explosion1x = 0
explosion1y = 0

explosion2x = 0
explosion2y = 0

pygame.mixer.music.load('sounds/BACKROUND.mp3')
pygame.mixer.music.play(-1)
    
def redrawWindow():
    global bomb1x
    global bomb1y

    global bomb2x
    global bomb2y

    global walkCount
    global walkCount2

    global explosion1x
    global explosion1y

    global explosion2x
    global explosion2y

    global explosion1
    global explosion2

    win.blit(bg, (0,0))
    win.blit(P1_NAME,(x-10, y - 20))
    win.blit(P2_NAME,(x2, y2 - 20))
    #win.blit(bomb_sprite,(0 + 30, 0))

    if walkCount + 1 >= 0:
        walkCount = 0

    if left:
        win.blit(walkLeft_green[walkCount//60], (x,y))
        walkCount += 1
    elif right:
        win.blit(walkRight_green[walkCount//60], (x,y))
        walkCount += 1
    else:
        win.blit(char_green, (x,y))
        
    if bomb1 == True:
        bomb1x = x
        bomb1y = y
        win.blit(bomb_sprite,(bomb1x - 15, bomb1y))
        
    if bomb1_placed == True:
        win.blit(bomb_sprite,(bomb1x, bomb1y))
        
    if bomb2 == True:
        bomb2x = x2
        bomb2y = y2
        win.blit(bomb2_sprite,(bomb2x + 30, bomb2y))
        
    if bomb2_placed == True:
        win.blit(bomb2_sprite,(bomb2x, bomb2y))

    if explosion1 == True:
        explosion1x = bomb1x
        explosion1y = bomb1y
        win.blit(explosion1_sprite,(explosion1x, explosion1y))
        win.blit(explosion1_sprite,(explosion1x, explosion1y))
        win.blit(explosion1_sprite,(explosion1x, explosion1y))
        win.blit(explosion1_sprite,(explosion1x, explosion1y))
        BOOM.play()
        explosion1 = False
        pygame.time.delay(100)



##################################################
    
    if walkCount + 1 >= 0:
        walkCount2 = 0

    if left2:
        win.blit(walkLeft_red[walkCount2//3], (x2,y2))
        walkCount2 += 1
    elif right2:
        win.blit(walkRight_red[walkCount2//3], (x2,y2))
        walkCount2 += 1
    else:
        win.blit(char_red, (x2,y2))

    if explosion2 == True:
        explosion2x = bomb2x
        explosion2y = bomb2y
        win.blit(explosion1_sprite,(explosion2x, explosion2y))
        win.blit(explosion1_sprite,(explosion2x, explosion2y))
        win.blit(explosion1_sprite,(explosion2x, explosion2y))
        win.blit(explosion1_sprite,(explosion2x, explosion2y))
        BOOM.play()
        explosion2 = False
        pygame.time.delay(100)

##############################################
    pygame.display.update() 
##############################################

while run:
    clock.tick(20)
    #pygame.time.delay(100)
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
        
    keys = pygame.key.get_pressed()
    
    if keys[pygame.K_a] and x > border:
        x -= vel
        left = True
        right = False

    elif keys[pygame.K_d] and x < 1200 - width - border:
        x += vel
        left = False
        right = True
    else:
        left = False
        right = False
        walkCount = 0

    if keys[pygame.K_w] and y > border:
        y -= vel

    if keys[pygame.K_s] and y < 600 - height - border:
        y += vel
        
    if keys[pygame.K_q]:
        bomb1 = True
        bomb1_placed = False
    
    if keys[pygame.K_e]:
        bomb1 = False
        bomb1_placed = True
        bomb1y = y
        bomb1x = x

    if keys[pygame.K_x]:
        bomb1 = False
        bomb1_placed = False
        explosion1 = True
        explosion1_render = True


    
        
#############################
        
    if keys[pygame.K_LEFT]  and x2 > border:
        x2 -= vel2
        left2 = True
        right2 = False

    elif keys[pygame.K_RIGHT] and x2 < 1200 - width - border:
        x2 += vel2
        left2 = False
        right2 = True
    else:
        left2 = False
        right2 = False
        walkCount2 = 0

    if keys[pygame.K_UP] and y2 > border:
        y2 -= vel2

    if keys[pygame.K_DOWN] and y2 < 600 - height - border:
        y2 += vel2
        
    if keys[pygame.K_0]:
        bomb2 = True
        bomb2_placed = False
    
    if keys[pygame.K_1]:
        bomb2 = False
        bomb2_placed = True
        bomb2y = y2
        bomb2x = x2

    if keys[pygame.K_2]:
        bomb2 = False
        bomb2_placed = False
        explosion2 = True
        explosion2_render = True

    redrawWindow()
    
    
pygame.quit()